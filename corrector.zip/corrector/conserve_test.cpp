#include "conserve.h"
#include <cstdio>
#include <cstdlib>
#include <cmath>
int main(){
  const long N=200000; float* x=new float[N]; float* orig=new float[N];
  srand(7);
  for(long i=0;i<N;i++){ double t=(double)i/N; orig[i]=(float)(sin(20*t)+0.3*t*t+0.05*((rand()%1000)/1000.0)); x[i]=orig[i]; }
  // targets from original
  double M0=0,S0=0; for(long i=0;i<N;i++){ M0+=orig[i]; S0+=(double)orig[i]*orig[i]; }
  // simulate lossy compression: quantize to a step
  double q=0.02; for(long i=0;i<N;i++) x[i]=(float)(round(x[i]/q)*q);
  double Mq=0,Sq=0; for(long i=0;i<N;i++){ Mq+=x[i]; Sq+=(double)x[i]*x[i]; }
  // correct
  conserve_mass_energy(x,N,M0,S0);
  double Mc=0,Sc=0,maxd=0; for(long i=0;i<N;i++){ Mc+=x[i]; Sc+=(double)x[i]*x[i]; double d=fabs((double)x[i]-orig[i]); if(d>maxd)maxd=d; }
  printf("mass  drift: quantized %.3e -> corrected %.3e\n", fabs(Mq-M0)/fabs(M0), fabs(Mc-M0)/fabs(M0));
  printf("energy drift: quantized %.3e -> corrected %.3e\n", fabs(Sq-S0)/fabs(S0), fabs(Sc-S0)/fabs(S0));
  printf("max pointwise change from rescale: %.3e (quant step q=%.3f)\n", maxd, q);
  // linear-only test on a fresh copy
  for(long i=0;i<N;i++) x[i]=(float)(round(orig[i]/q)*q);
  conserve_linear(x,N,M0);
  double Ml=0; for(long i=0;i<N;i++) Ml+=x[i];
  printf("linear(mass)-only: %.3e -> %.3e\n", fabs(Mq-M0)/fabs(M0), fabs(Ml-M0)/fabs(M0));
  delete[] x; delete[] orig; return 0;
}
